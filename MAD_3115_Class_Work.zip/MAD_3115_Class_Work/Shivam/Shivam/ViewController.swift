//
//  ViewController.swift
//  Shivam
//
//  Created by MacStudent on 2018-08-03.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var lblName: UILabel!
    @IBAction func btnGreet(_ sender: UIButton) {
        lblName.isHidden = false
        lblName.text=txtName.text
        
        print("Name: \(String(describing: lblName.text))")
        
        let nameAlert = UIAlertController(title: "Name", message: lblName.text, preferredStyle: .actionSheet)
        nameAlert.addAction(UIAlertAction(title: "DISMISS", style: .cancel, handler: nil))
        nameAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: nil))
        nameAlert.addAction(UIAlertAction(title: "Don't bother about it ", style: .destructive, handler: nil))
        
        self.present(nameAlert, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        lblName.isHidden = true
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

